# UB SEDS Software Design Document — Overleaf template

## Start a new SDD

1. Upload `UBSEDS-SDD-Template-Overleaf.zip` as a **New Project → Upload Project** in Overleaf.
2. Select **main.tex** as the main document and **XeLaTeX** as the compiler.
3. Edit `metadata.tex`: project name, document ID, author/reviewer, version, status, target and repository baseline.
4. Work through `sections/` in order. Replace every TBD and illustrative example. Retain explicit reasons for non-applicable sections.
5. Edit the four TikZ diagrams in `figures/`; add project-specific diagrams as needed.
6. Record source evidence, measured limits, actual test results and unresolved decisions. Do not present proposals as implemented features.
7. After authoring, change `\showguidancetrue` to `\showguidancefalse` in metadata.tex to hide blue guidance. This does NOT remove TBDs; resolve or track those separately.
8. Recompile and review the PDF, figures, links and tables before requesting review.

All assets are bundled. No shell escape, Mermaid, external tools or repository checkout is required to compile. The provided persistence/flow examples illustrate documentation technique and are not requirements or implemented behavior for your new system.

## Files

- `main.tex`: package setup and section order.
- `metadata.tex`: reusable project/document fields.
- `ubseds-brand.sty`: shared cover styling and original UB SEDS logo placement.
- `assets/`: original organization logo and provenance.
- `sections/`: document control, 14 design sections, and data dictionary appendix.
- `figures/`: context, startup, request/response and state diagrams.

## Local build

```sh
latexmk -xelatex -interaction=nonstopmode -halt-on-error -outdir=build main.tex
```

The template uses standard TeX Live packages. Keep its folder structure when copying or uploading it. For a local new document, copy this folder to a new directory, remove copied build output if any, and edit the metadata; retain the original template as a clean starting point.
