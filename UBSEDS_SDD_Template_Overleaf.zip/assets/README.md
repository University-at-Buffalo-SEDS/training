# UB SEDS logo

Organization: University at Buffalo SEDS.
Source: https://github.com/University-at-Buffalo-SEDS
Asset: https://avatars.githubusercontent.com/u/56740093?v=4&s=1024
Retrieved: 2026-09-11. Original PNG is embedded without recoloring or redrawing.
The logo remains the property of its owner. Included for UB SEDS documentation.
