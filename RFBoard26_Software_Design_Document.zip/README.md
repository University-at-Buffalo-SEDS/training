# RFBoard26 SDD — Overleaf project

Upload `RFBoard26-SDD-Overleaf.zip` as a new Overleaf project. Select **main.tex** as the main document and **XeLaTeX** as the compiler, then Recompile. Standard TeX Live packages are sufficient; no shell escape, Pandoc, Mermaid, or external image generator is needed.

- `main.tex`: title, contents, list of figures, formatting, section includes.
- `sections/01.tex` through `sections/19.tex`: editable sections, including the complete network schema appendix.
- `figures/01-diagram.tex` through `figures/08-diagram.tex`: editable TikZ diagrams.

Local build from this directory:

```sh
latexmk -xelatex -interaction=nonstopmode -halt-on-error main.tex
```

The document distinguishes implemented behavior, inferred design objectives, and proposed changes. Source references use original RFBoard26 repository paths. Repository files are not required for compilation; relative repository hyperlinks only work when the repository is available at the referenced location. External reference links work in the PDF.

Baseline: RFBoard26 commit b4eba479b57f767d07c7c9a811c741bc043990e6. Original Markdown files in the parent sdd folder are retained as the earlier edition; this LaTeX project is the expanded edition to edit going forward.
